from django.shortcuts import render,redirect,HttpResponse
from adminpanelapp .models import SuperAdmin,Category,Products
from django.views.decorators.cache import cache_control
import os
# from datetime import date

# today = date.today()  # Today's date (without time)
# print("Today========", today)

@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def Login(request):
    return render(request,"adminpanelapp/login.html")

def Logindata(request):
     if request.POST.get('submit')=="Submit":
        luser=request.POST.get('username')
        lpass=request.POST.get('password')
        print("name=======",luser)
        print("name=======",lpass)

        if luser and lpass:
            user=SuperAdmin.objects.filter(username=luser,password=lpass).first()
            print("user=======",user)
            if user:
                userid=request.session['member']=user.id
                print("userid=========",userid)
                return redirect("home")
            else:
               return redirect("login")
            
def Register(request):
    if request.POST.get('submit')=="Submit":
        name=request.POST.get('name')
        email=request.POST.get('email')
        username=request.POST.get('username')
        password=request.POST.get('password')
        print("name=======",name)
        print("name=======",email)
        print("name=======",username)
        print("name=======",password)

        if name and email and username and password:
            SuperAdmin.objects.create(name=name,email=email,username=username,password=password)
            return redirect("login")
        else:
            return render(request,"adminpanelapp/register.html")
    return render(request,"adminpanelapp/register.html")

# @cache_control(no_cache=True, must_revalidate=True, no_store=True)
def Home(request):
    return render(request, "adminpanelapp/index.html")


def add_category(request):
     if request.POST.get('submit')=="Submit": 
        id=request.POST.get('id')
        category=request.POST.get('category')
        print("name======",category)
        print("id======",id) 
        if (id):
            Category.objects.filter(id=id).update(category_name=category)
            return redirect("category")
        else:
            Category.objects.create(category_name=category)
            return redirect("category")
     name=request.GET.get('search','')
     if name:
        categorydata=Category.objects.filter(category_name__icontains=name)
     else:
        categorydata=Category.objects.all()
     return render(request,"adminpanelapp/category.html",{"categorydata":categorydata,"name":name})


def Editdata(request):
    editid=request.GET.get('editid')
    print("editid======",editid)
    editdata=Category.objects.filter(id=editid).first()
    categorydata=Category.objects.all()
    return render(request,"adminpanelapp/category.html",{'alledit':editdata,"categorydata":categorydata} )

def deletedata(request):
    delid=request.GET.get('delid')
    print("editid======",delid)
    Category.objects.get(id=delid).delete()
    return redirect("category")


def add_product(request):
    if request.POST.get('submit')=="Submit":
        id=request.POST.get('id')
        Category_id=request.POST.get('Category_id')
        Name=request.POST.get('Name')
        Price=request.POST.get('Price')
        photo=request.FILES['photo']
        Discription=request.POST.get('Discription')
        available_qty=request.POST.get('available_qty')
        print(Category_id)
        print(Name)
        print(Price)
        print("photo", request.FILES)
        print(Discription)
        if id:
            print("id=============",id)
            category=Category.objects.get(id=Category_id)
            select_product = Products.objects.get(id=id)
            print("category====",category)
            # if len(request.FILES)!=0:
            #     if select_product.product_image!="":
            #         try:
            #             os.remove(select_product.product_image.path)
            #         except:
            #             pass
            #         photo= request.FILES['photo']
            #     else:
            #         photo= request.FILES['photo']
            
            # Products.objects.filter(id=id).update(category_id=category,product_name=Name,product_price=Price,product_image=photo,product_discription=Discription,available_qty=available_qty)
            form = Products(request.POST, request.FILES)
            if form.is_valid():
                handle_uploaded_file(request.FILES["file"])

            return redirect("product")
        else:
            category=Category.objects.get(id=Category_id)
            Products.objects.create(category_id=category,product_name=Name,product_price=Price,product_image=photo,product_discription=Discription,available_qty=available_qty)
            return redirect("product")
    categorydata=Category.objects.all()
    productdata=Products.objects.all()
    return render(request,"adminpanelapp/product.html",{"productdata":productdata,"categorydata":categorydata})

def Productedit(request):
    proeditid=request.GET.get("proeditid")
    proeditdata=Products.objects.filter(id=proeditid).first()
    print("proeditid====",proeditdata.category_id.id)
    productdata=Products.objects.all()
    categorydata=Category.objects.all()
    return render(request,"adminpanelapp/product.html",{"proeditdata":proeditdata,"productdata":productdata,"categorydata":categorydata})

def Productdelete(request):
    prodelid=request.GET.get('prodelid')
    print("prodelid======",prodelid)
    Products.objects.get(id=prodelid).delete()
    return redirect("product")




        
