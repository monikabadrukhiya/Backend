from django.contrib import admin
from.models import Signdata,Admission,Inquiry

admin.site.register(Signdata)
admin.site.register(Admission)
admin.site.register(Inquiry)
